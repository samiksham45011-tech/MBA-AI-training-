export type MenuCategory =
  | 'All Dishes'
  | 'Mumbai Street Legends'
  | 'Trendy Fusions'
  | 'Traditional Classics'
  | 'Sweet & Cooling';

export type DietaryTag = 'Pure Veg' | 'Jain Option' | 'Gluten-Free';

export type SpiceLevel = 1 | 2 | 3;

export interface DishItem {
  id: string;
  name: string;
  marathi: string;
  category: Exclude<MenuCategory, 'All Dishes'>;
  price: number;
  description: string;
  image: string;
  dietary: DietaryTag[];
  spiceLevel: SpiceLevel;
  spiceLabel: 'Mild' | 'Kolhapuri Kick' | 'Thecha Fire';
  regionNote: string;
}

export interface CartItem {
  cartKey: string;
  id: string;
  name: string;
  marathi: string;
  price: number;
  quantity: number;
  image: string;
  customizationNote?: string;
}

export interface ThaliItem {
  id: number;
  name: string;
  marathi: string;
  role: string;
  description: string;
  xPercent: number;
  yPercent: number;
}

export interface LocationInfo {
  id: string;
  city: string;
  neighborhood: string;
  address: string;
  hours: string;
  phone: string;
  seatingNote: string;
  mapX: number;
  mapY: number;
  landmark: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  detail?: string;
}
