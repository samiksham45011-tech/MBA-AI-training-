import React, { useMemo, useState } from 'react';
import { Flame, Minus, Plus, Search } from 'lucide-react';
import { DISHES, MENU_CATEGORIES } from '../data/menuData';
import { CartItem, DietaryTag, DishItem, MenuCategory, SpiceLevel } from '../types';
import { SafeImage } from './CulturalMotifs';

interface HeritageAndMenuProps {
  activeCategory: MenuCategory;
  onCategoryChange: (cat: MenuCategory) => void;
  cart: CartItem[];
  onAddToCart: (dish: DishItem) => void;
  onUpdateQuantity: (cartKey: string, delta: number) => void;
}

export const HeritageAndMenu: React.FC<HeritageAndMenuProps> = ({
  activeCategory,
  onCategoryChange,
  cart,
  onAddToCart,
  onUpdateQuantity,
}) => {
  const [spiceFilter, setSpiceFilter] = useState<'All' | SpiceLevel>('All');
  const [dietaryFilter, setDietaryFilter] = useState<'All' | DietaryTag>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDishes = useMemo(() => {
    return DISHES.filter((dish) => {
      if (activeCategory !== 'All Dishes' && dish.category !== activeCategory) {
        return false;
      }
      if (spiceFilter !== 'All' && dish.spiceLevel !== spiceFilter) {
        return false;
      }
      if (dietaryFilter !== 'All' && !dish.dietary.includes(dietaryFilter)) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          dish.name.toLowerCase().includes(q) ||
          dish.description.toLowerCase().includes(q) ||
          dish.marathi.includes(q)
        );
      }
      return true;
    });
  }, [activeCategory, spiceFilter, dietaryFilter, searchQuery]);

  const getCartQuantity = (dishId: string) => {
    const found = cart.find((item) => item.cartKey === dishId);
    return found ? found.quantity : 0;
  };

  return (
    <>
      {/* Heritage Narrative Section */}
      <section id="heritage" className="py-10 lg:py-14 bg-[#FAF6F0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
            <div className="lg:col-span-7">
              <p className="text-xs font-semibold tracking-wider text-[#C83E2B] uppercase mb-2">
                01. Our Heritage
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1E1916] leading-tight">
                Two Worlds on One Brass Platter: Ancestral Recipes &amp; Street Evolution.
              </h2>
            </div>
            <div className="lg:col-span-5">
              <p className="text-sm sm:text-base text-[#6B5E55] leading-relaxed">
                From the iron tawas of Dadar to the quiet spice rooms of Pune’s Wadas, we honor
                time-tested Maharashtrian craftsmanship—stone-ground Bedgi chilies, Konkan kokum,
                and slow-roasted Goda masala—while pairing them with playful modern textures.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Menu Showcase */}
      <section id="menu" className="py-12 lg:py-16 bg-[#F2EAE1]/60 border-y border-[#1E1916]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
            <div>
              <p className="text-xs font-semibold tracking-wider text-[#C83E2B] uppercase mb-2">
                02. The Kitchen Menu
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1E1916]">
                Curated Street Legends &amp; Classics
              </h2>
            </div>

            {/* Clean Search Input */}
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-[#6B5E55] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Vada Pav, Misal, Modak..."
                aria-label="Search menu dishes"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-[#FAF6F0] border border-[#1E1916]/15 rounded-lg text-[#1E1916] placeholder:text-[#6B5E55]/70 focus:outline-none focus:border-[#C83E2B]"
              />
            </div>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 pb-4 border-b border-[#1E1916]/10">
            {MENU_CATEGORIES.map((category) => {
              const active = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => onCategoryChange(category)}
                  className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#1E1916] text-[#FAF6F0] shadow-sm'
                      : 'bg-[#FAF6F0] text-[#1E1916]/80 hover:text-[#C83E2B] border border-[#1E1916]/10'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          {/* Secondary Dietary & Spice Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 py-4 mb-6 text-xs sm:text-sm">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[#6B5E55] font-medium mr-1">Spice Heat:</span>
              {(
                [
                  { label: 'All Heat', value: 'All' },
                  { label: 'Mild', value: 1 },
                  { label: 'Kolhapuri Kick', value: 2 },
                  { label: 'Thecha Fire', value: 3 },
                ] as const
              ).map((item) => (
                <button
                  key={String(item.value)}
                  type="button"
                  onClick={() => setSpiceFilter(item.value)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    spiceFilter === item.value
                      ? 'bg-[#C83E2B] text-[#FAF6F0]'
                      : 'bg-transparent text-[#6B5E55] hover:text-[#1E1916] border border-[#1E1916]/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[#6B5E55] font-medium mr-1">Dietary:</span>
              {(['All', 'Pure Veg', 'Jain Option', 'Gluten-Free'] as const).map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setDietaryFilter(tag)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    dietaryFilter === tag
                      ? 'bg-[#E59A24] text-[#1E1916] font-semibold'
                      : 'bg-transparent text-[#6B5E55] hover:text-[#1E1916] border border-[#1E1916]/10'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Uniform 3-Column Dish Grid */}
          {filteredDishes.length === 0 ? (
            <div className="bg-[#FAF6F0] rounded-2xl border border-[#1E1916]/10 p-12 text-center">
              <p className="font-serif text-xl font-semibold text-[#1E1916]">
                No dishes match those exact spice &amp; dietary filters.
              </p>
              <p className="text-sm text-[#6B5E55] mt-2">
                Reset filters to explore all 12 Maharashtrian classics and fusions.
              </p>
              <button
                type="button"
                onClick={() => {
                  onCategoryChange('All Dishes');
                  setSpiceFilter('All');
                  setDietaryFilter('All');
                  setSearchQuery('');
                }}
                className="mt-5 px-5 py-2.5 text-sm font-semibold bg-[#1E1916] text-[#FAF6F0] rounded-lg hover:bg-[#C83E2B] transition-colors cursor-pointer"
              >
                Show All Dishes
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
              {filteredDishes.map((dish) => {
                const qty = getCartQuantity(dish.id);
                return (
                  <article
                    key={dish.id}
                    className="group flex flex-col bg-[#FAF6F0] rounded-2xl border border-[#1E1916]/10 overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md"
                  >
                    {/* 4:3 Image Frame */}
                    <div className="relative aspect-[4/3] overflow-hidden bg-[#F2EAE1]">
                      <SafeImage
                        src={dish.image}
                        alt={dish.name}
                        fallbackTitle={dish.name}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>

                    {/* Card Body */}
                    <div className="flex-1 flex flex-col p-6">
                      {/* Clean unboxed metadata line */}
                      <div className="flex items-center justify-between gap-2 text-xs text-[#6B5E55] mb-2">
                        <span className="truncate font-medium">
                          {dish.dietary.join(' · ')}
                        </span>
                        <span
                          className="inline-flex items-center gap-1 font-medium text-[#C83E2B] shrink-0"
                          title={`Spice level: ${dish.spiceLabel}`}
                        >
                          <span className="inline-flex items-center" aria-hidden="true">
                            {[1, 2, 3].map((lvl) => (
                              <Flame
                                key={lvl}
                                className={`w-3.5 h-3.5 ${
                                  lvl <= dish.spiceLevel
                                    ? 'text-[#C83E2B] fill-[#C83E2B]'
                                    : 'text-[#1E1916]/15'
                                }`}
                              />
                            ))}
                          </span>
                          <span>{dish.spiceLabel}</span>
                        </span>
                      </div>

                      {/* Title + Marathi Script */}
                      <div className="flex items-baseline justify-between gap-3">
                        <h3 className="font-serif text-xl font-bold text-[#1E1916] leading-snug">
                          {dish.name}
                        </h3>
                      </div>
                      <p className="text-xs font-medium text-[#E59A24] mt-0.5">
                        {dish.marathi} · {dish.regionNote}
                      </p>

                      {/* 2-line sensory description */}
                      <p className="mt-3 text-sm text-[#6B5E55] leading-relaxed line-clamp-2 flex-1">
                        {dish.description}
                      </p>

                      {/* Price & Action Footer */}
                      <div className="mt-5 pt-4 border-t border-[#1E1916]/10 flex items-center justify-between gap-4">
                        <span className="font-serif text-xl font-bold text-[#1E1916] tabular-nums">
                          ₹{dish.price}
                        </span>

                        {qty === 0 ? (
                          <button
                            type="button"
                            onClick={() => onAddToCart(dish)}
                            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-[#FAF6F0] bg-[#1E1916] hover:bg-[#C83E2B] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add to Order</span>
                          </button>
                        ) : (
                          <div className="inline-flex items-center gap-1 bg-[#1E1916] text-[#FAF6F0] rounded-lg p-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(dish.id, -1)}
                              aria-label={`Decrease ${dish.name} quantity`}
                              className="w-7 h-7 inline-flex items-center justify-center rounded-md hover:bg-[#FAF6F0]/15 transition-colors cursor-pointer"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-7 text-center text-sm font-semibold tabular-nums">
                              {qty}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(dish.id, 1)}
                              aria-label={`Increase ${dish.name} quantity`}
                              className="w-7 h-7 inline-flex items-center justify-center rounded-md hover:bg-[#FAF6F0]/15 transition-colors cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </>
  );
};
