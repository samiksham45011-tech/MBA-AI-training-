import React, { useState } from 'react';
import { Calendar, Plus } from 'lucide-react';
import { ROYAL_THALI_IMAGE, THALI_ITEMS } from '../data/menuData';
import { SafeImage, WarliDivider } from './CulturalMotifs';

interface RoyalThaliSpotlightProps {
  onAddThaliToCart: () => void;
  onBookThaliTable: () => void;
}

export const RoyalThaliSpotlight: React.FC<RoyalThaliSpotlightProps> = ({
  onAddThaliToCart,
  onBookThaliTable,
}) => {
  const [selectedId, setSelectedId] = useState<number>(2);
  const activeItem = THALI_ITEMS.find((item) => item.id === selectedId) || THALI_ITEMS[0];

  return (
    <section id="thali" className="py-16 lg:py-24 bg-[#1E1916] text-[#FAF6F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <WarliDivider dark className="mb-10" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left: Interactive Hotspot Thali Photo */}
          <div className="lg:col-span-6">
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#E59A24]/30 bg-[#2B2420] shadow-2xl">
              <SafeImage
                src={ROYAL_THALI_IMAGE}
                alt="Grand Maharashtrian Festive Thali served on hammered brass platter with 12 traditional courses"
                fallbackTitle="Grand Maharashtrian Festive Thali"
                className="w-full h-full object-cover"
              />

              {/* Subtle Interactive Hotspots */}
              {THALI_ITEMS.map((item) => {
                const isSelected = item.id === selectedId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedId(item.id)}
                    style={{ left: `${item.xPercent}%`, top: `${item.yPercent}%` }}
                    aria-label={`Inspect ${item.name}`}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full text-xs font-bold tabular-nums flex items-center justify-center transition-all duration-200 cursor-pointer shadow-md ${
                      isSelected
                        ? 'bg-[#E59A24] text-[#1E1916] scale-115 ring-4 ring-[#E59A24]/35'
                        : 'bg-[#1E1916]/85 text-[#FAF6F0] border border-[#FAF6F0]/50 hover:bg-[#C83E2B] hover:border-[#FAF6F0]'
                    }`}
                  >
                    {item.id}
                  </button>
                );
              })}
            </div>

            {/* Active Hotspot Detail Readout */}
            <div className="mt-4 p-5 rounded-xl bg-[#2B2420] border border-[#E59A24]/25">
              <div className="flex items-baseline justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-[#E59A24] tracking-wide">
                    Course {String(activeItem.id).padStart(2, '0')} · {activeItem.role} ·{' '}
                    {activeItem.marathi}
                  </p>
                  <h3 className="font-serif text-xl font-bold text-[#FAF6F0] mt-1">
                    {activeItem.name}
                  </h3>
                </div>
              </div>
              <p className="text-sm text-[#FAF6F0]/80 mt-1.5 leading-relaxed">
                {activeItem.description}
              </p>
            </div>
          </div>

          {/* Right: 12-Item Breakdown & Order Actions */}
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold tracking-wider text-[#E59A24] uppercase mb-2">
              04. Royal Contrast Feast
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#FAF6F0] leading-tight">
              The Grand Maharashtrian Festive Thali
            </h2>
            <p className="mt-4 text-sm sm:text-base text-[#FAF6F0]/80 leading-relaxed">
              Served on hand-hammered kansa brass for lunch and dinner. Tap any number on the
              platter or list below to inspect all 12 ceremonial preparations—from Batata Bhaji to
              Kesar Shrikhand.
            </p>

            {/* 12-Item Interactive Grid */}
            <div className="mt-7 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {THALI_ITEMS.map((item) => {
                const isSelected = item.id === selectedId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedId(item.id)}
                    className={`text-left px-3 py-2.5 rounded-lg border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#E59A24] text-[#1E1916] border-[#E59A24]'
                        : 'bg-[#2B2420]/70 text-[#FAF6F0]/90 border-[#FAF6F0]/10 hover:border-[#E59A24]/45'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-bold tabular-nums ${
                          isSelected ? 'text-[#1E1916]' : 'text-[#E59A24]'
                        }`}
                      >
                        {String(item.id).padStart(2, '0')}.
                      </span>
                      <span className="text-xs font-semibold truncate">{item.name}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Pricing & CTAs */}
            <div className="mt-8 pt-6 border-t border-[#FAF6F0]/15 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-xs text-[#FAF6F0]/65">Complete 12-Item Platter</p>
                <p className="font-serif text-3xl font-bold text-[#E59A24] tabular-nums">
                  ₹695{' '}
                  <span className="text-sm font-sans font-normal text-[#FAF6F0]/70">
                    / unlimited refills in-house
                  </span>
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={onAddThaliToCart}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold bg-[#E59A24] hover:bg-[#f0a835] text-[#1E1916] rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Thali Box · ₹695</span>
                </button>

                <button
                  type="button"
                  onClick={onBookThaliTable}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold border border-[#FAF6F0]/25 hover:border-[#E59A24] text-[#FAF6F0] rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-[#E59A24]" />
                  <span>Reserve Dining</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
