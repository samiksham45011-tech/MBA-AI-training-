import React, { useState } from 'react';
import { Utensils } from 'lucide-react';

export const BrandEmblem: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <circle cx="20" cy="20" r="18.5" stroke="#C83E2B" strokeWidth="1.5" />
    <circle cx="20" cy="20" r="14.5" stroke="#E59A24" strokeWidth="1" strokeDasharray="2 2.5" />
    {/* Paithani lotus & mortar spice silhouette */}
    <path
      d="M20 9C22.2 13.4 25.6 15.8 29 17.5C25.2 19.3 22.8 22.4 20 27C17.2 22.4 14.8 19.3 11 17.5C14.4 15.8 17.8 13.4 20 9Z"
      fill="#C83E2B"
    />
    <path
      d="M14 28.5C15.8 30.2 17.8 31 20 31C22.2 31 24.2 30.2 26 28.5"
      stroke="#E59A24"
      strokeWidth="1.75"
      strokeLinecap="round"
    />
  </svg>
);

export const WarliDivider: React.FC<{ dark?: boolean; className?: string }> = ({
  dark = false,
  className = '',
}) => {
  const strokeColor = dark ? '#E59A24' : '#C83E2B';
  return (
    <div className={`w-full overflow-hidden py-1 ${className}`} aria-hidden="true">
      <svg
        viewBox="0 0 1200 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-5 opacity-45"
        preserveAspectRatio="none"
      >
        <line x1="0" y1="12" x2="1200" y2="12" stroke={strokeColor} strokeOpacity="0.35" strokeWidth="1" />
        <pattern id={`warli-${dark ? 'dark' : 'light'}`} x="0" y="0" width="48" height="24" patternUnits="userSpaceOnUse">
          <polygon points="12,4 20,12 12,20 4,12" stroke={strokeColor} strokeWidth="1.2" fill="none" />
          <circle cx="12" cy="12" r="1.5" fill={strokeColor} />
          <path d="M28 12 L36 6 L44 12 L36 18 Z" stroke={strokeColor} strokeWidth="1.1" fill="none" />
        </pattern>
        <rect x="0" y="0" width="1200" height="24" fill={`url(#warli-${dark ? 'dark' : 'light'})`} />
      </svg>
    </div>
  );
};

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle,
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#F2EAE1] via-[#FAF6F0] to-[#E9DDD0] text-[#6B5E55] p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Utensils className="w-7 h-7 text-[#C83E2B]/70 mb-2" strokeWidth={1.5} />
        <span className="font-serif text-sm font-semibold text-[#1E1916]">
          {fallbackTitle || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      loading="lazy"
    />
  );
};
