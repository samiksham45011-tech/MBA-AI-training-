import React from 'react';
import { ArrowRight, Flame, ShieldCheck, Star } from 'lucide-react';
import { HERO_FEATURE_IMAGE } from '../data/menuData';
import { SafeImage, WarliDivider } from './CulturalMotifs';

interface HeroProps {
  onExploreMenu: () => void;
  onJumpToCustomizer: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onJumpToCustomizer }) => {
  return (
    <section id="top" className="relative bg-[#FAF6F0] pt-8 pb-12 lg:pt-14 lg:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Left Editorial Column */}
          <div className="lg:col-span-6 flex flex-col justify-center py-2 lg:py-6">
            <p className="text-xs sm:text-sm font-medium tracking-wide text-[#C83E2B] mb-4">
              Maharashtra Kitchen &amp; Street Craft · Mumbai · Pune · Nagpur
            </p>

            <h1 className="font-serif text-[clamp(2.25rem,3.9vw,3.65rem)] font-bold leading-[1.08] tracking-tight text-[#1E1916] max-w-xl">
              From Mumbai’s Bustling Streets to Royal Maratha Kitchens.
            </h1>

            <p className="mt-5 text-base sm:text-lg text-[#6B5E55] leading-relaxed max-w-xl">
              Hand-pounded spices, stone-ground chutneys, and bold contemporary twists on
              Maharashtra’s most iconic flavors.
            </p>

            {/* Dual CTAs */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onExploreMenu}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-[#FAF6F0] bg-[#C83E2B] hover:bg-[#A9301F] rounded-lg transition-all duration-200 shadow-sm hover:-translate-y-0.5 whitespace-nowrap cursor-pointer"
              >
                <span>Explore Menu</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onJumpToCustomizer}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#1E1916] bg-[#F2EAE1] hover:bg-[#E8DDD0] border border-[#1E1916]/15 rounded-lg transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                <span>Build Your Vada Pav</span>
              </button>
            </div>

            {/* Clean unboxed trust strip */}
            <div className="mt-9 pt-6 border-t border-[#1E1916]/10 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs sm:text-sm text-[#6B5E55]">
              <span className="inline-flex items-center gap-1.5 font-medium text-[#1E1916]">
                <ShieldCheck className="w-4 h-4 text-[#C83E2B]" />
                100% Authentic Stone-Ground Masalas
              </span>
              <span aria-hidden="true" className="text-[#1E1916]/25">
                ·
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium text-[#1E1916]">
                <Star className="w-4 h-4 text-[#E59A24] fill-[#E59A24]" />
                4.9★ Rated Heritage Kitchen
              </span>
              <span aria-hidden="true" className="text-[#1E1916]/25">
                ·
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium text-[#1E1916]">
                <Flame className="w-4 h-4 text-[#C83E2B]" />
                Freshly Fried to Order
              </span>
            </div>
          </div>

          {/* Right Split Visual Anchor */}
          <div className="lg:col-span-6 relative min-h-[320px] sm:min-h-[420px] lg:min-h-[480px] rounded-2xl overflow-hidden bg-[#F2EAE1] border border-[#1E1916]/10 shadow-sm">
            <SafeImage
              src={HERO_FEATURE_IMAGE}
              alt="Steaming Classic Mumbai Vada Pav with blistered green chilies, dry lasun chutney, and cutting chai"
              fallbackTitle="Classic Mumbai Vada Pav & Cutting Chai"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#1E1916]/85 via-[#1E1916]/40 to-transparent p-6 sm:p-7">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-[#E59A24] tracking-wide">
                    House Signature · वडा पाव
                  </p>
                  <p className="font-serif text-lg sm:text-xl font-semibold text-[#FAF6F0] mt-0.5">
                    Dadar Heritage Batata Vada &amp; Dry Lasun Chutney
                  </p>
                </div>
                <span className="tabular-nums text-sm font-semibold text-[#FAF6F0] whitespace-nowrap shrink-0">
                  ₹110
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Kitchen Highlights Strip */}
        <div className="mt-10 lg:mt-12 grid grid-cols-2 lg:grid-cols-4 gap-6 py-6 px-6 rounded-xl bg-[#F2EAE1]/80 border border-[#1E1916]/10">
          <div>
            <p className="font-serif text-2xl font-bold text-[#1E1916] tabular-nums">18 Spices</p>
            <p className="text-xs sm:text-sm text-[#6B5E55] mt-1">
              Stone-pounded daily in our Goda Masala mill
            </p>
          </div>
          <div>
            <p className="font-serif text-2xl font-bold text-[#1E1916] tabular-nums">12 Courses</p>
            <p className="text-xs sm:text-sm text-[#6B5E55] mt-1">
              Served on hammered kansa brass in our Festive Thali
            </p>
          </div>
          <div>
            <p className="font-serif text-2xl font-bold text-[#1E1916] tabular-nums">3 Cities</p>
            <p className="text-xs sm:text-sm text-[#6B5E55] mt-1">
              Bandra West, Koregaon Park &amp; Civil Lines
            </p>
          </div>
          <div>
            <p className="font-serif text-2xl font-bold text-[#1E1916] tabular-nums">4.9 / 5.0</p>
            <p className="text-xs sm:text-sm text-[#6B5E55] mt-1">
              Rated across 3,400+ heritage dining guests
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <WarliDivider />
      </div>
    </section>
  );
};
