import React, { useMemo, useState } from 'react';
import { Check, Flame, Minus, Plus, ShoppingBag } from 'lucide-react';
import {
  CUSTOMIZER_ADDONS,
  CUSTOMIZER_BASES,
  CUSTOMIZER_CHUTNEYS,
  CUSTOMIZER_DISHES,
} from '../data/menuData';
import { SafeImage } from './CulturalMotifs';

interface MealCustomizerProps {
  onAddCustomItem: (item: {
    cartKey: string;
    id: string;
    name: string;
    marathi: string;
    price: number;
    quantity: number;
    image: string;
    customizationNote: string;
  }) => void;
}

export const MealCustomizer: React.FC<MealCustomizerProps> = ({ onAddCustomItem }) => {
  const [dishTypeIndex, setDishTypeIndex] = useState(0);
  const [selectedBaseId, setSelectedBaseId] = useState(CUSTOMIZER_BASES[0].id);
  const [selectedChutneyId, setSelectedChutneyId] = useState(CUSTOMIZER_CHUTNEYS[0].id);
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>(['fried-chilies']);
  const [quantity, setQuantity] = useState(1);

  const selectedDish = CUSTOMIZER_DISHES[dishTypeIndex];
  const selectedBase = CUSTOMIZER_BASES.find((b) => b.id === selectedBaseId) || CUSTOMIZER_BASES[0];
  const selectedChutney =
    CUSTOMIZER_CHUTNEYS.find((c) => c.id === selectedChutneyId) || CUSTOMIZER_CHUTNEYS[0];
  const selectedAddons = CUSTOMIZER_ADDONS.filter((a) => selectedAddonIds.includes(a.id));

  const unitPrice = useMemo(() => {
    const addonsTotal = selectedAddons.reduce((sum, addon) => sum + addon.price, 0);
    return selectedDish.basePrice + selectedBase.price + selectedChutney.price + addonsTotal;
  }, [selectedDish, selectedBase, selectedChutney, selectedAddons]);

  const toggleAddon = (id: string) => {
    setSelectedAddonIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleAdd = () => {
    const addonNames = selectedAddons.map((a) => a.name).join(', ');
    const note = `${selectedBase.name} · ${selectedChutney.name}${
      addonNames ? ` · + ${addonNames}` : ''
    }`;
    const sortedAddonKey = [...selectedAddonIds].sort().join('-');
    const cartKey = `${selectedDish.id}__${selectedBase.id}__${selectedChutney.id}__${sortedAddonKey}`;

    onAddCustomItem({
      cartKey,
      id: selectedDish.id,
      name: `Custom ${selectedDish.label}`,
      marathi: selectedDish.marathi,
      price: unitPrice,
      quantity,
      image: selectedDish.image,
      customizationNote: note,
    });
    setQuantity(1);
  };

  return (
    <section id="customizer" className="py-14 lg:py-20 bg-[#FAF6F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <p className="text-xs font-semibold tracking-wider text-[#C83E2B] uppercase mb-2">
              03. Craft Your Street Bite
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1E1916]">
              The Vada Pav &amp; Misal Customizer
            </h2>
          </div>

          {/* Dish Craft Toggle */}
          <div className="inline-flex p-1 bg-[#F2EAE1] rounded-xl border border-[#1E1916]/10 self-start">
            {CUSTOMIZER_DISHES.map((dish, idx) => (
              <button
                key={dish.id}
                type="button"
                onClick={() => setDishTypeIndex(idx)}
                className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  dishTypeIndex === idx
                    ? 'bg-[#1E1916] text-[#FAF6F0]'
                    : 'text-[#6B5E55] hover:text-[#1E1916]'
                }`}
              >
                {dish.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Customization Steps */}
          <div className="lg:col-span-7 space-y-8 bg-[#F2EAE1]/70 rounded-2xl p-6 sm:p-8 border border-[#1E1916]/10">
            {/* Step 1: Choose Base */}
            <div>
              <div className="flex items-baseline justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-[#1E1916]">
                  1. Choose Your Base
                </h3>
                <span className="text-xs text-[#6B5E55]">Select 1 bread or bhakri</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CUSTOMIZER_BASES.map((base) => {
                  const active = selectedBaseId === base.id;
                  return (
                    <button
                      key={base.id}
                      type="button"
                      onClick={() => setSelectedBaseId(base.id)}
                      className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#FAF6F0] border-[#C83E2B] ring-1 ring-[#C83E2B]'
                          : 'bg-[#FAF6F0]/70 border-[#1E1916]/10 hover:border-[#1E1916]/30'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-sm font-semibold text-[#1E1916] leading-snug">
                          {base.name}
                        </span>
                        <span className="text-xs font-semibold text-[#C83E2B] tabular-nums shrink-0">
                          {base.price === 0 ? 'Incl.' : `+₹${base.price}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#6B5E55] mt-1.5 leading-relaxed">{base.detail}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Choose Chutney Level */}
            <div>
              <div className="flex items-baseline justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-[#1E1916]">
                  2. Choose Chutney &amp; Heat Level
                </h3>
                <span className="text-xs text-[#6B5E55]">Stone-ground daily</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CUSTOMIZER_CHUTNEYS.map((chutney) => {
                  const active = selectedChutneyId === chutney.id;
                  return (
                    <button
                      key={chutney.id}
                      type="button"
                      onClick={() => setSelectedChutneyId(chutney.id)}
                      className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#FAF6F0] border-[#C83E2B] ring-1 ring-[#C83E2B]'
                          : 'bg-[#FAF6F0]/70 border-[#1E1916]/10 hover:border-[#1E1916]/30'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-sm font-semibold text-[#1E1916] leading-snug">
                          {chutney.name}
                        </span>
                        <span className="text-xs font-semibold text-[#C83E2B] tabular-nums shrink-0">
                          {chutney.price === 0 ? 'Incl.' : `+₹${chutney.price}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#6B5E55] mt-1.5 inline-flex items-center gap-1">
                        <Flame className="w-3 h-3 text-[#C83E2B]" />
                        <span>{chutney.heat}</span>
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Add-ons */}
            <div>
              <div className="flex items-baseline justify-between mb-3">
                <h3 className="font-serif text-lg font-bold text-[#1E1916]">
                  3. Select Optional Add-ons
                </h3>
                <span className="text-xs text-[#6B5E55]">Layer extra crunch or richness</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {CUSTOMIZER_ADDONS.map((addon) => {
                  const checked = selectedAddonIds.includes(addon.id);
                  return (
                    <button
                      key={addon.id}
                      type="button"
                      onClick={() => toggleAddon(addon.id)}
                      className={`flex items-center justify-between gap-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        checked
                          ? 'bg-[#FAF6F0] border-[#C83E2B] ring-1 ring-[#C83E2B]'
                          : 'bg-[#FAF6F0]/70 border-[#1E1916]/10 hover:border-[#1E1916]/30'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className={`w-5 h-5 rounded-md flex items-center justify-center border shrink-0 transition-colors ${
                            checked
                              ? 'bg-[#C83E2B] border-[#C83E2B] text-[#FAF6F0]'
                              : 'border-[#1E1916]/25 bg-white'
                          }`}
                        >
                          {checked && <Check className="w-3.5 h-3.5" />}
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#1E1916] truncate">
                            {addon.name}
                          </p>
                          <p className="text-xs text-[#6B5E55] truncate">{addon.detail}</p>
                        </div>
                      </div>
                      <span className="text-xs font-semibold text-[#1E1916] tabular-nums shrink-0">
                        +₹{addon.price}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Live Ticket Summary */}
          <div className="lg:col-span-5 bg-[#1E1916] text-[#FAF6F0] rounded-2xl overflow-hidden shadow-lg border border-[#E59A24]/25">
            <div className="aspect-[16/10] relative overflow-hidden">
              <SafeImage
                src={selectedDish.image}
                alt={selectedDish.label}
                fallbackTitle={selectedDish.label}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1E1916] via-[#1E1916]/30 to-transparent" />
              <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-[#E59A24]">
                    Live Kitchen Ticket · {selectedDish.marathi}
                  </p>
                  <h3 className="font-serif text-2xl font-bold text-[#FAF6F0]">
                    Custom {selectedDish.label}
                  </h3>
                </div>
              </div>
            </div>

            <div className="p-6 sm:p-7 space-y-5">
              <div className="space-y-2.5 text-sm border-b border-[#FAF6F0]/15 pb-4">
                <div className="flex justify-between gap-4">
                  <span className="text-[#FAF6F0]/75">Kitchen Base ({selectedDish.label})</span>
                  <span className="font-medium tabular-nums">₹{selectedDish.basePrice}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-[#FAF6F0]/75">Bread: {selectedBase.name}</span>
                  <span className="font-medium tabular-nums">
                    {selectedBase.price === 0 ? '₹0' : `+₹${selectedBase.price}`}
                  </span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-[#FAF6F0]/75">Chutney: {selectedChutney.name}</span>
                  <span className="font-medium tabular-nums">
                    {selectedChutney.price === 0 ? '₹0' : `+₹${selectedChutney.price}`}
                  </span>
                </div>
                {selectedAddons.map((addon) => (
                  <div key={addon.id} className="flex justify-between gap-4">
                    <span className="text-[#E59A24]">+ {addon.name}</span>
                    <span className="font-medium tabular-nums">+₹{addon.price}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-[#FAF6F0]/65">Total for {quantity} serving(s)</p>
                  <p className="font-serif text-3xl font-bold text-[#E59A24] tabular-nums">
                    ₹{unitPrice * quantity}
                  </p>
                </div>

                {/* Quantity Stepper */}
                <div className="inline-flex items-center gap-1 bg-[#2B2420] rounded-lg p-1 border border-[#FAF6F0]/15">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease custom order quantity"
                    className="w-8 h-8 inline-flex items-center justify-center rounded-md hover:bg-[#FAF6F0]/10 transition-colors cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center text-sm font-semibold tabular-nums">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    aria-label="Increase custom order quantity"
                    className="w-8 h-8 inline-flex items-center justify-center rounded-md hover:bg-[#FAF6F0]/10 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAdd}
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-[#1E1916] bg-[#E59A24] hover:bg-[#f0a835] rounded-xl transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add Custom Creation to Order · ₹{unitPrice * quantity}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
