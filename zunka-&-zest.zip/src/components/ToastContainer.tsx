import React from 'react';
import { CheckCircle2, X } from 'lucide-react';
import { ToastMessage } from '../types';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-[calc(100%-2.5rem)] pointer-events-none"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-start gap-3 bg-[#1E1916] text-[#FAF6F0] px-4 py-3.5 rounded-xl shadow-xl border border-[#E59A24]/30 transition-all duration-200"
        >
          <CheckCircle2 className="w-5 h-5 text-[#E59A24] shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold leading-snug">{toast.title}</p>
            {toast.detail && (
              <p className="text-xs text-[#FAF6F0]/75 mt-0.5 leading-relaxed">{toast.detail}</p>
            )}
          </div>
          <button
            type="button"
            onClick={() => onDismiss(toast.id)}
            aria-label="Dismiss notification"
            className="text-[#FAF6F0]/60 hover:text-[#FAF6F0] p-1 -mr-1 -mt-1 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
