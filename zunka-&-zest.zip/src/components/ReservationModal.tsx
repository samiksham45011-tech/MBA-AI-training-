import React, { useEffect, useState } from 'react';
import { Calendar, CheckCircle2, Clock, Minus, Plus, Users, X } from 'lucide-react';
import { LOCATIONS } from '../data/menuData';

interface ReservationModalProps {
  isOpen: boolean;
  initialCity?: string;
  onClose: () => void;
  onShowToast: (title: string, detail?: string) => void;
}

const TIME_SLOTS = ['12:30 PM', '1:45 PM', '7:00 PM', '8:15 PM', '9:30 PM'];
const OCCASIONS = [
  'Family Dinner',
  'Casual Street-Food Date',
  'Corporate Lunch',
  'Festive Thali Gathering',
];

export const ReservationModal: React.FC<ReservationModalProps> = ({
  isOpen,
  initialCity,
  onClose,
  onShowToast,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [city, setCity] = useState(
    initialCity || `${LOCATIONS[0].neighborhood}, ${LOCATIONS[0].city}`
  );
  const [date, setDate] = useState(todayStr);
  const [timeSlot, setTimeSlot] = useState(TIME_SLOTS[2]);
  const [guests, setGuests] = useState(2);
  const [occasion, setOccasion] = useState(OCCASIONS[0]);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [bookingRef, setBookingRef] = useState<string | null>(null);

  useEffect(() => {
    if (initialCity) {
      setCity(initialCity);
    }
  }, [initialCity]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim() || !guestPhone.trim()) {
      onShowToast('Please enter guest details', 'Name and phone number confirm your table.');
      return;
    }

    const ref = `TBL-${Math.floor(1000 + Math.random() * 9000)}`;
    setBookingRef(ref);
    onShowToast(
      `Table Reserved (${ref})`,
      `${guests} guests at ${city} on ${date} · ${timeSlot}`
    );
  };

  const handleClose = () => {
    setBookingRef(null);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1E1916]/65 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label="Reserve a Table"
    >
      <div className="relative w-full max-w-xl bg-[#FAF6F0] text-[#1E1916] rounded-2xl shadow-2xl border border-[#1E1916]/15 overflow-hidden my-8">
        {/* Top Header */}
        <div className="px-6 py-5 bg-[#1E1916] text-[#FAF6F0] flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-[#E59A24]">Zunka &amp; Zest Dining Room</p>
            <h2 className="font-serif text-xl sm:text-2xl font-bold mt-0.5">
              Reserve Your Brass Table
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close reservation modal"
            className="p-2 rounded-lg text-[#FAF6F0]/70 hover:text-[#FAF6F0] hover:bg-[#FAF6F0]/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {bookingRef ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#E59A24]/20 text-[#C83E2B] flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#C83E2B]">
              Reservation Confirmed
            </p>
            <h3 className="font-serif text-2xl font-bold text-[#1E1916]">
              Booking #{bookingRef}
            </h3>
            <p className="text-sm text-[#6B5E55] max-w-md mx-auto leading-relaxed">
              We look forward to hosting {guestName} &amp; party for{' '}
              <span className="font-semibold text-[#1E1916]">{occasion}</span>.
            </p>

            <div className="p-4 rounded-xl bg-[#F2EAE1] border border-[#1E1916]/10 text-left text-sm space-y-2 max-w-sm mx-auto">
              <div className="flex justify-between">
                <span className="text-[#6B5E55]">Location</span>
                <span className="font-semibold">{city}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6B5E55]">Date &amp; Time</span>
                <span className="font-semibold tabular-nums">
                  {date} · {timeSlot}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6B5E55]">Guests</span>
                <span className="font-semibold tabular-nums">{guests} Guests</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleClose}
              className="mt-4 px-8 py-3 text-sm font-semibold bg-[#1E1916] text-[#FAF6F0] rounded-xl hover:bg-[#C83E2B] transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-5">
            {/* Location Selector */}
            <div>
              <label className="block text-xs font-semibold text-[#6B5E55] uppercase tracking-wide mb-2">
                Select Kitchen Location
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {LOCATIONS.map((loc) => {
                  const label = `${loc.neighborhood}, ${loc.city}`;
                  const active = city === label;
                  return (
                    <button
                      key={loc.id}
                      type="button"
                      onClick={() => setCity(label)}
                      className={`px-3 py-2.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#C83E2B] text-[#FAF6F0] border-[#C83E2B]'
                          : 'bg-[#F2EAE1]/60 text-[#1E1916] border-[#1E1916]/10 hover:border-[#1E1916]/30'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Date & Guest Count */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="res-date"
                  className="flex items-center gap-1.5 text-xs font-semibold text-[#6B5E55] uppercase tracking-wide mb-2"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#C83E2B]" />
                  <span>Date</span>
                </label>
                <input
                  id="res-date"
                  type="date"
                  min={todayStr}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#1E1916]/15 rounded-lg focus:outline-none focus:border-[#C83E2B] tabular-nums"
                />
              </div>

              <div>
                <span className="flex items-center gap-1.5 text-xs font-semibold text-[#6B5E55] uppercase tracking-wide mb-2">
                  <Users className="w-3.5 h-3.5 text-[#C83E2B]" />
                  <span>Party Size</span>
                </span>
                <div className="flex items-center justify-between px-3 py-1.5 bg-white border border-[#1E1916]/15 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setGuests((g) => Math.max(1, g - 1))}
                    aria-label="Decrease guests"
                    className="w-8 h-8 inline-flex items-center justify-center rounded-md hover:bg-[#F2EAE1] cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-sm font-semibold tabular-nums">{guests} Guests</span>
                  <button
                    type="button"
                    onClick={() => setGuests((g) => Math.min(12, g + 1))}
                    aria-label="Increase guests"
                    className="w-8 h-8 inline-flex items-center justify-center rounded-md hover:bg-[#F2EAE1] cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Time Slots */}
            <div>
              <span className="flex items-center gap-1.5 text-xs font-semibold text-[#6B5E55] uppercase tracking-wide mb-2">
                <Clock className="w-3.5 h-3.5 text-[#C83E2B]" />
                <span>Preferred Seating Time</span>
              </span>
              <div className="flex flex-wrap gap-2">
                {TIME_SLOTS.map((slot) => (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setTimeSlot(slot)}
                    className={`px-3.5 py-2 text-xs font-semibold rounded-lg border tabular-nums transition-colors cursor-pointer ${
                      timeSlot === slot
                        ? 'bg-[#1E1916] text-[#FAF6F0] border-[#1E1916]'
                        : 'bg-white text-[#1E1916] border-[#1E1916]/15 hover:border-[#C83E2B]'
                    }`}
                  >
                    {slot}
                  </button>
                ))}
              </div>
            </div>

            {/* Occasion */}
            <div>
              <span className="block text-xs font-semibold text-[#6B5E55] uppercase tracking-wide mb-2">
                Occasion
              </span>
              <div className="flex flex-wrap gap-2">
                {OCCASIONS.map((occ) => (
                  <button
                    key={occ}
                    type="button"
                    onClick={() => setOccasion(occ)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      occasion === occ
                        ? 'bg-[#E59A24] text-[#1E1916] border-[#E59A24] font-semibold'
                        : 'bg-[#F2EAE1]/60 text-[#6B5E55] border-[#1E1916]/10 hover:text-[#1E1916]'
                    }`}
                  >
                    {occ}
                  </button>
                ))}
              </div>
            </div>

            {/* Guest Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <input
                type="text"
                required
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="Guest Name"
                aria-label="Guest Name"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#1E1916]/15 rounded-lg focus:outline-none focus:border-[#C83E2B]"
              />
              <input
                type="tel"
                required
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder="Phone Number (+91)"
                aria-label="Phone Number"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#1E1916]/15 rounded-lg focus:outline-none focus:border-[#C83E2B]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 text-sm font-semibold bg-[#C83E2B] hover:bg-[#A9301F] text-[#FAF6F0] rounded-xl transition-colors shadow-sm cursor-pointer"
            >
              Confirm Table Reservation
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
