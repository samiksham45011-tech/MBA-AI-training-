import React, { useState } from 'react';
import { Calendar, Menu, ShoppingBag, X } from 'lucide-react';
import { BrandEmblem } from './CulturalMotifs';
import { MenuCategory } from '../types';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
  onSelectCategoryAndScroll: (category: MenuCategory) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenReservation,
  onSelectCategoryAndScroll,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavClick = (sectionId: string, category?: MenuCategory) => {
    setMobileOpen(false);
    if (category) {
      onSelectCategoryAndScroll(category);
      return;
    }
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF6F0]/90 backdrop-blur-md border-b border-[#1E1916]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand wordmark (single line) */}
        <a
          href="#top"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#C83E2B] rounded-md"
        >
          <BrandEmblem className="w-8 h-8 shrink-0" />
          <span className="font-serif text-lg sm:text-xl font-bold tracking-tight text-[#1E1916]">
            ZUNKA &amp; ZEST
          </span>
        </a>

        {/* Zone 2: Concise single-line nav links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#1E1916]/75"
        >
          <button
            type="button"
            onClick={() => handleNavClick('heritage')}
            className="hover:text-[#C83E2B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            Our Heritage
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('menu', 'All Dishes')}
            className="hover:text-[#C83E2B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            The Menu
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('menu', 'Trendy Fusions')}
            className="hover:text-[#C83E2B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            Trendy Fusions
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('thali')}
            className="hover:text-[#C83E2B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            Chef&apos;s Thali
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('locations')}
            className="hover:text-[#C83E2B] transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            Catering &amp; Events
          </button>
        </nav>

        {/* Zone 3: Action controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onOpenReservation}
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-[#1E1916] hover:text-[#C83E2B] border border-[#1E1916]/15 hover:border-[#C83E2B]/40 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Book a Table</span>
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            aria-label={`Open order cart, ${cartCount} items`}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-[#FAF6F0] bg-[#C83E2B] hover:bg-[#A9301F] rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Order Cart</span>
            <span className="tabular-nums inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5 text-xs font-bold bg-[#FAF6F0] text-[#C83E2B] rounded-md">
              {cartCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
            className="lg:hidden inline-flex items-center justify-center p-2 text-[#1E1916] hover:text-[#C83E2B] rounded-lg border border-[#1E1916]/15 cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-[#1E1916]/10 bg-[#FAF6F0] px-4 py-4 space-y-2">
          <button
            type="button"
            onClick={() => handleNavClick('heritage')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-[#1E1916] hover:bg-[#F2EAE1] rounded-lg"
          >
            Our Heritage
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('menu', 'All Dishes')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-[#1E1916] hover:bg-[#F2EAE1] rounded-lg"
          >
            The Menu
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('menu', 'Trendy Fusions')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-[#1E1916] hover:bg-[#F2EAE1] rounded-lg"
          >
            Trendy Fusions
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('thali')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-[#1E1916] hover:bg-[#F2EAE1] rounded-lg"
          >
            Chef&apos;s Thali
          </button>
          <button
            type="button"
            onClick={() => handleNavClick('locations')}
            className="block w-full text-left px-3 py-2.5 text-sm font-medium text-[#1E1916] hover:bg-[#F2EAE1] rounded-lg"
          >
            Catering &amp; Events
          </button>
          <button
            type="button"
            onClick={() => {
              setMobileOpen(false);
              onOpenReservation();
            }}
            className="w-full flex items-center justify-center gap-2 mt-2 px-4 py-2.5 text-sm font-semibold text-[#1E1916] border border-[#1E1916]/20 rounded-lg"
          >
            <Calendar className="w-4 h-4" />
            <span>Book a Table</span>
          </button>
        </div>
      )}
    </header>
  );
};
