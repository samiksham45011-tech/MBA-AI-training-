import React, { useState } from 'react';
import { CheckCircle2, Minus, Plus, ShoppingBag, Tag, Trash2, X } from 'lucide-react';
import { CartItem } from '../types';
import { SafeImage } from './CulturalMotifs';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (cartKey: string, delta: number) => void;
  onRemoveItem: (cartKey: string) => void;
  onClearCart: () => void;
  onShowToast: (title: string, detail?: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onShowToast,
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; rate: number } | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderMode, setOrderMode] = useState<'delivery' | 'pickup'>('delivery');
  const [confirmedOrder, setConfirmedOrder] = useState<{
    orderId: string;
    total: number;
    mode: string;
  } | null>(null);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedPromo ? Math.round(subtotal * appliedPromo.rate) : 0;
  const taxableAmount = Math.max(0, subtotal - discount);
  const gst = Math.round(taxableAmount * 0.05);
  const grandTotal = taxableAmount + gst;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoInput.trim().toUpperCase();
    if (!code) return;

    if (code === 'MUMBAI10') {
      setAppliedPromo({ code: 'MUMBAI10', rate: 0.1 });
      onShowToast('Promo MUMBAI10 applied', '10% heritage discount deducted from subtotal.');
    } else if (code === 'ZUNKA15') {
      if (subtotal < 600) {
        onShowToast('Add ₹600+ to unlock ZUNKA15', 'Use MUMBAI10 for 10% off any order.');
        return;
      }
      setAppliedPromo({ code: 'ZUNKA15', rate: 0.15 });
      onShowToast('Promo ZUNKA15 applied', '15% feast discount deducted from subtotal.');
    } else {
      onShowToast('Invalid promo code', 'Try MUMBAI10 for 10% off your order.');
    }
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      onShowToast('Enter name & phone number', 'Required to confirm kitchen preparation.');
      return;
    }

    const orderId = `ZZ-${Math.floor(1000 + Math.random() * 9000)}`;
    setConfirmedOrder({
      orderId,
      total: grandTotal,
      mode: orderMode === 'delivery' ? 'Express Kitchen Delivery (30–35 mins)' : 'Counter Pickup (18 mins)',
    });
    onClearCart();
    setAppliedPromo(null);
    setPromoInput('');
    onShowToast(`Order ${orderId} confirmed`, 'Fresh spices are hitting the tawa now.');
  };

  const handleClose = () => {
    setConfirmedOrder(null);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-[#1E1916]/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="Order Cart"
    >
      <div className="relative w-full max-w-md bg-[#FAF6F0] text-[#1E1916] h-full flex flex-col shadow-2xl border-l border-[#1E1916]/10">
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#1E1916]/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#C83E2B]" />
            <h2 className="font-serif text-xl font-bold">Your Kitchen Order</h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close order cart"
            className="p-2 rounded-lg text-[#6B5E55] hover:text-[#1E1916] hover:bg-[#F2EAE1] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {confirmedOrder ? (
            <div className="py-10 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#E59A24]/20 text-[#C83E2B] flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#C83E2B]">
                Kitchen Ticket Confirmed
              </p>
              <h3 className="font-serif text-2xl font-bold text-[#1E1916]">
                Order #{confirmedOrder.orderId}
              </h3>
              <p className="text-sm text-[#6B5E55] leading-relaxed max-w-xs mx-auto">
                Thank you, {customerName || 'Guest'}. Our chefs are preparing your Maharashtrian
                feast fresh to order.
              </p>
              <div className="p-4 rounded-xl bg-[#F2EAE1] border border-[#1E1916]/10 text-left text-sm space-y-2 mt-6">
                <div className="flex justify-between">
                  <span className="text-[#6B5E55]">Fulfillment</span>
                  <span className="font-semibold text-[#1E1916] text-right">
                    {confirmedOrder.mode}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B5E55]">Total Paid</span>
                  <span className="font-bold text-[#C83E2B] tabular-nums">
                    ₹{confirmedOrder.total}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="mt-6 w-full py-3 text-sm font-semibold bg-[#1E1916] text-[#FAF6F0] rounded-xl hover:bg-[#C83E2B] transition-colors cursor-pointer"
              >
                Back to Menu
              </button>
            </div>
          ) : cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <ShoppingBag className="w-10 h-10 text-[#6B5E55]/45 mx-auto" />
              <h3 className="font-serif text-xl font-bold text-[#1E1916]">Your tiffin is empty</h3>
              <p className="text-sm text-[#6B5E55] max-w-xs mx-auto">
                Explore Mumbai Street Legends, Trendy Fusions, or build your own Vada Pav to begin.
              </p>
              <button
                type="button"
                onClick={handleClose}
                className="mt-4 px-5 py-2.5 text-sm font-semibold bg-[#C83E2B] text-[#FAF6F0] rounded-lg hover:bg-[#A9301F] transition-colors cursor-pointer"
              >
                Browse Dishes
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Line Items */}
              <div className="space-y-4">
                {cart.map((item) => (
                  <div
                    key={item.cartKey}
                    className="flex gap-3.5 p-3.5 rounded-xl bg-[#F2EAE1]/70 border border-[#1E1916]/10"
                  >
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-[#F2EAE1] shrink-0">
                      <SafeImage
                        src={item.image}
                        alt={item.name}
                        fallbackTitle={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-serif text-sm font-bold text-[#1E1916] leading-snug">
                            {item.name}
                          </h4>
                          <p className="text-xs text-[#6B5E55]">{item.marathi}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.cartKey)}
                          aria-label={`Remove ${item.name}`}
                          className="text-[#6B5E55] hover:text-[#C83E2B] p-1 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {item.customizationNote && (
                        <p className="text-xs text-[#C83E2B] mt-1 leading-snug">
                          {item.customizationNote}
                        </p>
                      )}

                      <div className="mt-2.5 flex items-center justify-between gap-2">
                        <span className="text-sm font-bold text-[#1E1916] tabular-nums">
                          ₹{item.price * item.quantity}
                        </span>
                        <div className="inline-flex items-center gap-1 bg-[#FAF6F0] rounded-lg border border-[#1E1916]/15 p-0.5">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.cartKey, -1)}
                            aria-label={`Decrease ${item.name} quantity`}
                            className="w-6 h-6 inline-flex items-center justify-center rounded hover:bg-[#F2EAE1] cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-semibold tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.cartKey, 1)}
                            aria-label={`Increase ${item.name} quantity`}
                            className="w-6 h-6 inline-flex items-center justify-center rounded hover:bg-[#F2EAE1] cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Promo Code Input */}
              <form onSubmit={handleApplyPromo} className="space-y-2">
                <label className="block text-xs font-semibold text-[#6B5E55]">
                  Promo Code (Try <span className="text-[#C83E2B]">MUMBAI10</span>)
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-4 h-4 text-[#6B5E55] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      placeholder="MUMBAI10"
                      className="w-full pl-9 pr-3 py-2 text-sm bg-[#F2EAE1]/60 border border-[#1E1916]/15 rounded-lg uppercase focus:outline-none focus:border-[#C83E2B]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold bg-[#1E1916] text-[#FAF6F0] rounded-lg hover:bg-[#C83E2B] transition-colors cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
                {appliedPromo && (
                  <p className="text-xs text-[#C83E2B] font-medium flex items-center justify-between">
                    <span>Applied: {appliedPromo.code}</span>
                    <button
                      type="button"
                      onClick={() => setAppliedPromo(null)}
                      className="underline cursor-pointer"
                    >
                      Remove
                    </button>
                  </p>
                )}
              </form>

              {/* Itemized Bill Summary */}
              <div className="p-4 rounded-xl bg-[#F2EAE1]/80 border border-[#1E1916]/10 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#6B5E55]">Item Subtotal</span>
                  <span className="font-medium tabular-nums">₹{subtotal}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-[#C83E2B]">
                    <span>Promo Discount ({appliedPromo?.code})</span>
                    <span className="font-semibold tabular-nums">-₹{discount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[#6B5E55]">Restaurant GST (5%)</span>
                  <span className="font-medium tabular-nums">₹{gst}</span>
                </div>
                <div className="flex justify-between pt-2.5 border-t border-[#1E1916]/15 text-base font-bold">
                  <span>Grand Total</span>
                  <span className="font-serif text-xl text-[#C83E2B] tabular-nums">
                    ₹{grandTotal}
                  </span>
                </div>
              </div>

              {/* Checkout Details */}
              <form id="checkout-form" onSubmit={handlePlaceOrder} className="space-y-3">
                <div className="grid grid-cols-2 gap-2 p-1 bg-[#F2EAE1] rounded-lg border border-[#1E1916]/10">
                  <button
                    type="button"
                    onClick={() => setOrderMode('delivery')}
                    className={`py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      orderMode === 'delivery'
                        ? 'bg-[#1E1916] text-[#FAF6F0]'
                        : 'text-[#6B5E55] hover:text-[#1E1916]'
                    }`}
                  >
                    Express Delivery
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderMode('pickup')}
                    className={`py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      orderMode === 'pickup'
                        ? 'bg-[#1E1916] text-[#FAF6F0]'
                        : 'text-[#6B5E55] hover:text-[#1E1916]'
                    }`}
                  >
                    Kitchen Pickup
                  </button>
                </div>

                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Your Full Name"
                  aria-label="Your Full Name"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#1E1916]/15 rounded-lg focus:outline-none focus:border-[#C83E2B]"
                />
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="Mobile Number (+91)"
                  aria-label="Mobile Number"
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-[#1E1916]/15 rounded-lg focus:outline-none focus:border-[#C83E2B]"
                />
              </form>
            </div>
          )}
        </div>

        {/* Sticky Checkout Footer */}
        {cart.length > 0 && !confirmedOrder && (
          <div className="p-5 border-t border-[#1E1916]/10 bg-[#FAF6F0]">
            <button
              type="submit"
              form="checkout-form"
              className="w-full py-3.5 px-6 text-sm font-semibold bg-[#C83E2B] hover:bg-[#A9301F] text-[#FAF6F0] rounded-xl transition-colors shadow-sm cursor-pointer"
            >
              Place Order · ₹{grandTotal}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
