import React, { useState } from 'react';
import { Clock, Mail, MapPin, Phone, Quote, Star } from 'lucide-react';
import { LOCATIONS, REVIEWS } from '../data/menuData';
import { BrandEmblem, WarliDivider } from './CulturalMotifs';

interface SocialProofAndFooterProps {
  onShowToast: (title: string, detail?: string) => void;
  onOpenReservationForCity: (cityLabel: string) => void;
}

export const SocialProofAndFooter: React.FC<SocialProofAndFooterProps> = ({
  onShowToast,
  onOpenReservationForCity,
}) => {
  const [selectedLocId, setSelectedLocId] = useState(LOCATIONS[0].id);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const activeLocation = LOCATIONS.find((l) => l.id === selectedLocId) || LOCATIONS[0];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      onShowToast('Please enter a valid email address', 'Example: ananya@example.com');
      return;
    }
    setSubscribed(true);
    onShowToast(
      'Welcome to the Zunka & Zest Table',
      'Your 10% welcome code MUMBAI10 is active in the Order Cart.'
    );
    setNewsletterEmail('');
  };

  return (
    <>
      {/* Social Proof Reviews */}
      <section className="py-14 lg:py-20 bg-[#FAF6F0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-xs font-semibold tracking-wider text-[#C83E2B] uppercase mb-2">
                05. Voices Around the Table
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1E1916]">
                Loved by Purists &amp; Street-Food Explorers
              </h2>
            </div>
            <p className="text-sm text-[#6B5E55]">
              4.9★ Average across Mumbai, Pune &amp; Nagpur
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
            {REVIEWS.map((review) => (
              <article
                key={review.id}
                className="flex flex-col justify-between bg-[#F2EAE1]/65 rounded-2xl p-6 sm:p-7 border border-[#1E1916]/10"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <Quote className="w-6 h-6 text-[#C83E2B]/50" />
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#1E1916] tabular-nums">
                      <Star className="w-3.5 h-3.5 text-[#E59A24] fill-[#E59A24]" />
                      {review.rating}
                    </span>
                  </div>
                  <p className="text-sm sm:text-base text-[#1E1916] leading-relaxed">
                    “{review.quote}”
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#1E1916]/10">
                  <p className="font-serif text-base font-bold text-[#1E1916]">{review.name}</p>
                  <p className="text-xs text-[#6B5E55] mt-0.5">{review.role}</p>
                  <p className="text-xs font-medium text-[#C83E2B] mt-1">
                    Ordered: {review.dishOrdered}
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <WarliDivider />
      </div>

      {/* Locations, Interactive Map & Catering / Events */}
      <section id="locations" className="py-14 lg:py-20 bg-[#FAF6F0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            {/* Left: Interactive Location Selector & Info */}
            <div className="lg:col-span-6 flex flex-col justify-between">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#C83E2B] uppercase mb-2">
                  06. Visit Our Kitchens &amp; Catering
                </p>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1E1916]">
                  Three Flagship Dining Rooms Across Maharashtra
                </h2>
                <p className="mt-3 text-sm sm:text-base text-[#6B5E55] leading-relaxed">
                  Drop by for morning Misal, evening cutting chai with live Vada Pav, or book our
                  bespoke heritage Thali catering for weddings and studio gatherings.
                </p>

                {/* City Switcher */}
                <div className="mt-6 flex flex-wrap gap-2">
                  {LOCATIONS.map((loc) => {
                    const active = loc.id === selectedLocId;
                    return (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => setSelectedLocId(loc.id)}
                        className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#C83E2B] text-[#FAF6F0]'
                            : 'bg-[#F2EAE1] text-[#1E1916] hover:bg-[#E8DDD0]'
                        }`}
                      >
                        {loc.neighborhood}, {loc.city}
                      </button>
                    );
                  })}
                </div>

                {/* Selected Location Card */}
                <div className="mt-6 p-6 rounded-2xl bg-[#F2EAE1]/80 border border-[#1E1916]/10 space-y-4">
                  <div>
                    <p className="text-xs font-semibold text-[#C83E2B] uppercase tracking-wide">
                      {activeLocation.city} Flagship
                    </p>
                    <h3 className="font-serif text-2xl font-bold text-[#1E1916] mt-0.5">
                      Zunka &amp; Zest — {activeLocation.neighborhood}
                    </h3>
                  </div>

                  <div className="space-y-2.5 text-sm text-[#1E1916]/85">
                    <p className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-[#C83E2B] shrink-0 mt-0.5" />
                      <span>{activeLocation.address}</span>
                    </p>
                    <p className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-[#C83E2B] shrink-0 mt-0.5" />
                      <span>{activeLocation.hours}</span>
                    </p>
                    <p className="flex items-start gap-2.5">
                      <Phone className="w-4 h-4 text-[#C83E2B] shrink-0 mt-0.5" />
                      <span className="tabular-nums">{activeLocation.phone}</span>
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#1E1916]/10 flex flex-wrap items-center justify-between gap-3">
                    <span className="text-xs text-[#6B5E55]">{activeLocation.seatingNote}</span>
                    <button
                      type="button"
                      onClick={() =>
                        onOpenReservationForCity(
                          `${activeLocation.neighborhood}, ${activeLocation.city}`
                        )
                      }
                      className="text-xs font-semibold text-[#C83E2B] hover:underline cursor-pointer"
                    >
                      Book a Table Here →
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Interactive Architectural Map & Newsletter */}
            <div className="lg:col-span-6 flex flex-col gap-6">
              {/* Interactive Architectural Maharashtra Map */}
              <div className="relative flex-1 min-h-[280px] rounded-2xl overflow-hidden bg-[#1E1916] text-[#FAF6F0] border border-[#1E1916]/15 p-6 flex flex-col justify-between">
                <div className="flex items-center justify-between gap-4 relative z-10">
                  <div>
                    <p className="text-xs font-medium text-[#E59A24]">Interactive Kitchen Locator</p>
                    <p className="font-serif text-lg font-semibold mt-0.5">
                      {activeLocation.landmark}
                    </p>
                  </div>
                  <span className="text-xs text-[#FAF6F0]/70">Click pins to switch</span>
                </div>

                {/* Stylized Architectural Topographic Map SVG */}
                <svg
                  viewBox="0 0 400 220"
                  className="w-full h-44 my-2"
                  role="img"
                  aria-label="Stylized map of Maharashtra restaurant locations"
                >
                  {/* Subtle Grid Lines */}
                  <defs>
                    <pattern id="mapgrid" width="32" height="32" patternUnits="userSpaceOnUse">
                      <path
                        d="M 32 0 L 0 0 0 32"
                        fill="none"
                        stroke="#FAF6F0"
                        strokeOpacity="0.06"
                        strokeWidth="1"
                      />
                    </pattern>
                  </defs>
                  <rect width="400" height="220" fill="url(#mapgrid)" />

                  {/* Stylized Coastal & Deccan Contour Lines */}
                  <path
                    d="M 55 20 Q 75 95 62 195"
                    stroke="#E59A24"
                    strokeOpacity="0.25"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="4 4"
                  />
                  <path
                    d="M 112 123 L 184 145 L 296 79"
                    stroke="#E59A24"
                    strokeOpacity="0.45"
                    strokeWidth="1.5"
                    fill="none"
                  />

                  {/* Interactive Pins */}
                  {LOCATIONS.map((loc) => {
                    const cx = (loc.mapX / 100) * 400;
                    const cy = (loc.mapY / 100) * 220;
                    const active = loc.id === selectedLocId;
                    return (
                      <g
                        key={loc.id}
                        onClick={() => setSelectedLocId(loc.id)}
                        className="cursor-pointer"
                      >
                        {active && (
                          <circle
                            cx={cx}
                            cy={cy}
                            r="18"
                            fill="#E59A24"
                            fillOpacity="0.2"
                          />
                        )}
                        <circle
                          cx={cx}
                          cy={cy}
                          r={active ? 8 : 6}
                          fill={active ? '#E59A24' : '#C83E2B'}
                          stroke="#FAF6F0"
                          strokeWidth="2"
                        />
                        <text
                          x={cx}
                          y={cy - 14}
                          textAnchor="middle"
                          fill={active ? '#E59A24' : '#FAF6F0'}
                          fontSize="11"
                          fontWeight="600"
                        >
                          {loc.city}
                        </text>
                      </g>
                    );
                  })}
                </svg>

                <div className="flex items-center justify-between text-xs text-[#FAF6F0]/70 border-t border-[#FAF6F0]/10 pt-3">
                  <span>Private Catering &amp; Festive Hampers Available</span>
                  <span className="text-[#E59A24] font-medium">Promo: MUMBAI10</span>
                </div>
              </div>

              {/* Newsletter Signup */}
              <form
                onSubmit={handleNewsletterSubmit}
                className="p-6 rounded-2xl bg-[#F2EAE1] border border-[#1E1916]/10"
              >
                <div className="flex items-center gap-2 text-xs font-semibold text-[#C83E2B] uppercase tracking-wide mb-1.5">
                  <Mail className="w-3.5 h-3.5" />
                  <span>Chef’s Monsoon &amp; Festive Dispatch</span>
                </div>
                <p className="font-serif text-lg font-bold text-[#1E1916]">
                  Get seasonal Aamras alerts &amp; 10% off your first online order.
                </p>

                <div className="mt-4 flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email address"
                    aria-label="Email address for newsletter"
                    className="flex-1 px-4 py-2.5 text-sm bg-[#FAF6F0] border border-[#1E1916]/15 rounded-lg text-[#1E1916] placeholder:text-[#6B5E55]/70 focus:outline-none focus:border-[#C83E2B]"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-sm font-semibold bg-[#1E1916] hover:bg-[#C83E2B] text-[#FAF6F0] rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {subscribed ? 'Joined Table' : 'Join Dispatch'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Editorial Footer */}
      <footer className="bg-[#1E1916] text-[#FAF6F0] border-t border-[#FAF6F0]/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <BrandEmblem className="w-7 h-7" />
            <div>
              <span className="font-serif text-lg font-bold tracking-tight">ZUNKA &amp; ZEST</span>
              <span className="text-xs text-[#FAF6F0]/60 ml-3">
                Swad Maharashtra · Mumbai · Pune · Nagpur
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-[#FAF6F0]/70">
            <a href="#heritage" className="hover:text-[#E59A24] transition-colors">
              Heritage
            </a>
            <a href="#menu" className="hover:text-[#E59A24] transition-colors">
              Menu
            </a>
            <a href="#customizer" className="hover:text-[#E59A24] transition-colors">
              Vada Pav Builder
            </a>
            <a href="#thali" className="hover:text-[#E59A24] transition-colors">
              Royal Thali
            </a>
            <span className="text-[#FAF6F0]/45">© {new Date().getFullYear()} Zunka &amp; Zest</span>
          </div>
        </div>
      </footer>
    </>
  );
};
