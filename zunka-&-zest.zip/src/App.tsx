import { useCallback, useEffect, useState } from 'react';
import { CartDrawer } from './components/CartDrawer';
import { HeritageAndMenu } from './components/HeritageAndMenu';
import { Hero } from './components/Hero';
import { MealCustomizer } from './components/MealCustomizer';
import { Navbar } from './components/Navbar';
import { ReservationModal } from './components/ReservationModal';
import { RoyalThaliSpotlight } from './components/RoyalThaliSpotlight';
import { SocialProofAndFooter } from './components/SocialProofAndFooter';
import { ToastContainer } from './components/ToastContainer';
import { ROYAL_THALI_IMAGE } from './data/menuData';
import { CartItem, DishItem, MenuCategory, ToastMessage } from './types';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('All Dishes');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [reservationCity, setReservationCity] = useState<string | undefined>(undefined);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((title: string, detail?: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-2), { id, title, detail }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Close overlays with Escape key for accessibility
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsCartOpen(false);
        setIsReservationOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleAddToCart = (dish: DishItem) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.cartKey === dish.id);
      if (existing) {
        return prev.map((item) =>
          item.cartKey === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          cartKey: dish.id,
          id: dish.id,
          name: dish.name,
          marathi: dish.marathi,
          price: dish.price,
          quantity: 1,
          image: dish.image,
        },
      ];
    });
    showToast(`Added ${dish.name}`, `₹${dish.price} · Added to your kitchen order`);
  };

  const handleAddCustomItem = (customItem: CartItem) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.cartKey === customItem.cartKey);
      if (existing) {
        return prev.map((item) =>
          item.cartKey === customItem.cartKey
            ? { ...item, quantity: item.quantity + customItem.quantity }
            : item
        );
      }
      return [...prev, customItem];
    });
    showToast(
      `Added ${customItem.name}`,
      `${customItem.customizationNote} · ₹${customItem.price * customItem.quantity}`
    );
  };

  const handleAddThali = () => {
    const thaliKey = 'grand-maharashtrian-thali';
    setCart((prev) => {
      const existing = prev.find((item) => item.cartKey === thaliKey);
      if (existing) {
        return prev.map((item) =>
          item.cartKey === thaliKey ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          cartKey: thaliKey,
          id: thaliKey,
          name: 'Grand Maharashtrian Festive Thali',
          marathi: 'शाही महाराष्ट्रीयन थाळी',
          price: 695,
          quantity: 1,
          image: ROYAL_THALI_IMAGE,
          customizationNote: 'Complete 12-course ceremonial platter',
        },
      ];
    });
    showToast('Added Grand Maharashtrian Festive Thali', '₹695 · 12 courses packed fresh');
  };

  const handleUpdateQuantity = (cartKey: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.cartKey === cartKey ? { ...item, quantity: item.quantity + delta } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (cartKey: string) => {
    setCart((prev) => prev.filter((item) => item.cartKey !== cartKey));
  };

  const handleSelectCategoryAndScroll = (category: MenuCategory) => {
    setActiveCategory(category);
    const el = document.getElementById('menu');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF6F0] text-[#1E1916]">
      <Navbar
        cartCount={totalCartItems}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => {
          setReservationCity(undefined);
          setIsReservationOpen(true);
        }}
        onSelectCategoryAndScroll={handleSelectCategoryAndScroll}
      />

      <main className="flex-1">
        <Hero
          onExploreMenu={() => scrollToSection('menu')}
          onJumpToCustomizer={() => scrollToSection('customizer')}
        />

        <HeritageAndMenu
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          cart={cart}
          onAddToCart={handleAddToCart}
          onUpdateQuantity={handleUpdateQuantity}
        />

        <MealCustomizer onAddCustomItem={handleAddCustomItem} />

        <RoyalThaliSpotlight
          onAddThaliToCart={handleAddThali}
          onBookThaliTable={() => {
            setReservationCity(undefined);
            setIsReservationOpen(true);
          }}
        />

        <SocialProofAndFooter
          onShowToast={showToast}
          onOpenReservationForCity={(cityLabel) => {
            setReservationCity(cityLabel);
            setIsReservationOpen(true);
          }}
        />
      </main>

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={() => setCart([])}
        onShowToast={showToast}
      />

      <ReservationModal
        isOpen={isReservationOpen}
        initialCity={reservationCity}
        onClose={() => setIsReservationOpen(false)}
        onShowToast={showToast}
      />

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
