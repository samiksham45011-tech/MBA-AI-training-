import { DishItem, LocationInfo, ThaliItem } from '../types';

export const HERO_FEATURE_IMAGE = '/src/assets/images/dish_classic_vada_pav_1795244418524.jpg';
export const ROYAL_THALI_IMAGE = '/src/assets/images/royal_festive_thali_1795244418616.jpg';

export const MENU_CATEGORIES: Array<
  'All Dishes' | 'Mumbai Street Legends' | 'Trendy Fusions' | 'Traditional Classics' | 'Sweet & Cooling'
> = [
  'All Dishes',
  'Mumbai Street Legends',
  'Trendy Fusions',
  'Traditional Classics',
  'Sweet & Cooling',
];

export const DISHES: DishItem[] = [
  {
    id: 'classic-vada-pav',
    name: 'Classic Mumbai Vada Pav',
    marathi: 'वडा पाव',
    category: 'Mumbai Street Legends',
    price: 110,
    description:
      'Golden gram-flour batata vada nestled in pillowy ladi pav with dry roasted lasun chutney, mint coriander, and salted green chilies.',
    image: '/src/assets/images/dish_classic_vada_pav_1795244418524.jpg',
    dietary: ['Pure Veg'],
    spiceLevel: 2,
    spiceLabel: 'Kolhapuri Kick',
    regionNote: 'Dadar Station Heritage',
  },
  {
    id: 'crispy-kanda-bhaji',
    name: 'Crispy Kanda Bhaji',
    marathi: 'कांदा भजी',
    category: 'Mumbai Street Legends',
    price: 165,
    description:
      'Feather-light carom-scented onion fritters fried to crisp amber lace, served in hammered copper with tamarind jaggery and green thecha.',
    image: '/src/assets/images/dish_kanda_bhaji_1795244418517.jpg',
    dietary: ['Pure Veg', 'Gluten-Free'],
    spiceLevel: 2,
    spiceLabel: 'Kolhapuri Kick',
    regionNote: 'Sinhagad Monsoon Classic',
  },
  {
    id: 'buttered-pav-bhaji',
    name: 'Buttered Mumbai Pav Bhaji',
    marathi: 'पाव भाजी',
    category: 'Mumbai Street Legends',
    price: 245,
    description:
      'Slow-mashed heirloom vegetables simmered on a cast-iron tawa with stone-ground Kashmiri chili masala, crowned with melting butter and toasted pav.',
    image: '/src/assets/images/dish_pav_bhaji_1795244419753.jpg',
    dietary: ['Pure Veg', 'Jain Option'],
    spiceLevel: 2,
    spiceLabel: 'Kolhapuri Kick',
    regionNote: 'Juhu Chowpatty Tawa',
  },
  {
    id: 'tandoori-cheese-vada-pav',
    name: 'Tandoori Cheese Burst Vada Pav',
    marathi: 'तंदूरी चीज वडा पाव',
    category: 'Trendy Fusions',
    price: 195,
    description:
      'Artisan toasted brioche pav cradling a crisp spiced vada stuffed with molten aged cheddar, smoky tandoori emulsion, and crunchy chura.',
    image: '/src/assets/images/dish_cheese_vada_pav_1795244418007.jpg',
    dietary: ['Pure Veg'],
    spiceLevel: 2,
    spiceLabel: 'Kolhapuri Kick',
    regionNote: 'Bandra Studio Signature',
  },
  {
    id: 'peri-peri-misal-fondue',
    name: 'Peri-Peri Misal Fondue',
    marathi: 'मिसळ फोंड्यू',
    category: 'Trendy Fusions',
    price: 325,
    description:
      'Bubbling cast-iron cocotte of velvety Kolhapuri kat folded with aged fondue cheese, ruby pomegranate, sev farsan, and crisp garlic pav soldiers.',
    image: '/src/assets/images/dish_misal_fondue_1795244418450.jpg',
    dietary: ['Pure Veg'],
    spiceLevel: 3,
    spiceLabel: 'Thecha Fire',
    regionNote: 'Modern Maratha Tapas',
  },
  {
    id: 'nachni-sabudana-tacos',
    name: 'Crispy Nachni Sabudana Tacos',
    marathi: 'नाचणी साबुदाणा टाकोज',
    category: 'Trendy Fusions',
    price: 265,
    description:
      'Earthy roasted finger-millet taco shells filled with ghee-tempered sabudana pearls, crushed peanuts, pomegranate, and smoky kokum crema.',
    image: '/src/assets/images/dish_nachni_tacos_1795244417864.jpg',
    dietary: ['Pure Veg', 'Gluten-Free', 'Jain Option'],
    spiceLevel: 1,
    spiceLabel: 'Mild',
    regionNote: 'Konkan Millet Craft',
  },
  {
    id: 'puneri-misal-pav',
    name: 'Puneri Misal Pav',
    marathi: 'पुणेरी मिसळ पाव',
    category: 'Traditional Classics',
    price: 215,
    description:
      'Sprouted matki moth beans simmered in aromatic crimson tarri with poha, crunchy farsan, red onion, fresh lime, and twin soft ladi pav.',
    image: '/src/assets/images/dish_puneri_misal_1795244418587.jpg',
    dietary: ['Pure Veg'],
    spiceLevel: 3,
    spiceLabel: 'Thecha Fire',
    regionNote: 'Sadashiv Peth Lineage',
  },
  {
    id: 'kothimbir-vadi',
    name: 'Sesame Crusted Kothimbir Vadi',
    marathi: 'कोथिंबीर वडी',
    category: 'Traditional Classics',
    price: 185,
    description:
      'Steamed and pan-seared cakes of fresh farm coriander, chickpea flour, and toasted white sesame, finished with grated coconut and green thecha.',
    image: '/src/assets/images/dish_kothimbir_vadi_1795244418423.jpg',
    dietary: ['Pure Veg', 'Gluten-Free', 'Jain Option'],
    spiceLevel: 2,
    spiceLabel: 'Kolhapuri Kick',
    regionNote: 'Deccan Farmhouse Kitchen',
  },
  {
    id: 'thalipeeth-white-butter',
    name: 'Thalipeeth with Fresh White Loni',
    marathi: 'थालीपीठ लोणी',
    category: 'Traditional Classics',
    price: 225,
    description:
      'Hand-patted roasted five-grain bhajani flatbread griddled crisp and crowned with churned white butter, cooling curd, and pounded chili thecha.',
    image: '/src/assets/images/dish_thalipeeth_loni_1795244419601.jpg',
    dietary: ['Pure Veg', 'Gluten-Free'],
    spiceLevel: 1,
    spiceLabel: 'Mild',
    regionNote: 'Satara Grain Mill',
  },
  {
    id: 'puran-poli-desi-ghee',
    name: 'Saffron Puran Poli with Desi Ghee',
    marathi: 'पुरण पोळी',
    category: 'Sweet & Cooling',
    price: 195,
    description:
      'Paper-thin flaky flatbread stuffed with slow-cooked chana dal, organic Kolhapuri jaggery, cardamom, and nutmeg, bathed in warm A2 ghee.',
    image: '/src/assets/images/dish_puran_poli_1795244418351.jpg',
    dietary: ['Pure Veg', 'Jain Option'],
    spiceLevel: 1,
    spiceLabel: 'Mild',
    regionNote: 'Gudi Padwa Heirloom',
  },
  {
    id: 'ukadiche-modak',
    name: 'Steamed Ukadiche Modak',
    marathi: 'उकडीचे मोदक',
    category: 'Sweet & Cooling',
    price: 235,
    description:
      'Hand-pleated Ambemohar rice-flour dumplings steamed on banana leaf around warm freshly grated coconut, jaggery, and saffron ghee.',
    image: '/src/assets/images/dish_ukadiche_modak_1795244419359.jpg',
    dietary: ['Pure Veg', 'Gluten-Free', 'Jain Option'],
    spiceLevel: 1,
    spiceLabel: 'Mild',
    regionNote: 'Ratnagiri Coastal Craft',
  },
  {
    id: 'chilled-kokum-solkadhi',
    name: 'Chilled Konkan Solkadhi',
    marathi: 'सोलकढी',
    category: 'Sweet & Cooling',
    price: 145,
    description:
      'Velvety first-press coconut milk infused with sun-dried Sindhudurg kokum petals, roasted cumin, and fresh cilantro in a chilled brass tumbler.',
    image: '/src/assets/images/dish_solkadhi_kokum_1795244420481.jpg',
    dietary: ['Pure Veg', 'Gluten-Free', 'Jain Option'],
    spiceLevel: 1,
    spiceLabel: 'Mild',
    regionNote: 'Malvan Coast Cooler',
  },
];

export const CUSTOMIZER_DISHES = [
  {
    id: 'custom-vada-pav',
    label: 'Signature Vada Pav',
    marathi: 'वडा पाव',
    basePrice: 110,
    image: '/src/assets/images/dish_classic_vada_pav_1795244418524.jpg',
  },
  {
    id: 'custom-misal-pav',
    label: 'Kolhapuri Misal Bowl',
    marathi: 'मिसळ पाव',
    basePrice: 185,
    image: '/src/assets/images/dish_puneri_misal_1795244418587.jpg',
  },
] as const;

export const CUSTOMIZER_BASES = [
  { id: 'ladi-pav', name: 'Classic Ladi Pav', detail: 'Soft bakery-baked Mumbai square pav', price: 0 },
  { id: 'brioche-pav', name: 'Brioche Pav', detail: 'Rich toasted butter-glazed artisan bun', price: 45 },
  { id: 'multigrain-bhakri', name: 'Multigrain Bhakri', detail: 'Stone-ground jowar & bajra crisp disc', price: 55 },
];

export const CUSTOMIZER_CHUTNEYS = [
  { id: 'lasun', name: 'Dry Garlic (Lasun) Chutney', heat: 'Roasted & Nutty', price: 0 },
  { id: 'coriander-mint', name: 'Green Coriander-Mint', heat: 'Bright & Herbaceous', price: 0 },
  { id: 'red-thecha', name: 'Fiery Red Thecha', heat: 'Stone-Pounded Heat', price: 20 },
];

export const CUSTOMIZER_ADDONS = [
  { id: 'fried-chilies', name: 'Fried Green Chilies', detail: 'Blistered & sea-salted', price: 15 },
  { id: 'melted-cheddar', name: 'Melted Cheddar', detail: 'Aged sharp cheddar fold', price: 50 },
  { id: 'crunchy-chura', name: 'Crunchy Chura', detail: 'Crisp spiced besan pearls', price: 25 },
  { id: 'extra-kat', name: 'Extra Kat (Spicy Gravy)', detail: 'Simmered Kolhapuri tarri pour', price: 40 },
];

export const THALI_ITEMS: ThaliItem[] = [
  {
    id: 1,
    name: 'Fluffy Wheat Puris',
    marathi: 'टम्म फुगलेल्या पुऱ्या',
    role: 'Artisan Bread',
    description: 'Golden hand-rolled whole wheat puris puffed crisp in cold-pressed groundnut oil.',
    xPercent: 34,
    yPercent: 25,
  },
  {
    id: 2,
    name: 'Saffron Puran Poli',
    marathi: 'केसरी पुरण पोळी',
    role: 'Royal Sweet Flatbread',
    description: 'Delicate cardamom-nutmeg lentil and jaggery stuffed poli brushed with warm A2 ghee.',
    xPercent: 55,
    yPercent: 19,
  },
  {
    id: 3,
    name: 'Pivli Batata Bhaji',
    marathi: 'बटाटा भाजी',
    role: 'Tempered Vegetable',
    description: 'Heirloom potatoes tossed with mustard seeds, curry leaves, turmeric, and green chili.',
    xPercent: 72,
    yPercent: 31,
  },
  {
    id: 4,
    name: 'Varan Bhaat & Toop',
    marathi: 'वरण भात आणि तूप',
    role: 'Soulful Centerpiece',
    description: 'Steamed fragrant Indrayani rice crowned with silky tur dal varan and cumin-ghee tadka.',
    xPercent: 56,
    yPercent: 48,
  },
  {
    id: 5,
    name: 'Traditional Pithla',
    marathi: 'गरमागरम पिठलं',
    role: 'Hearty Besan Curry',
    description: 'Velvety slow-whisked chickpea flour simmered with garlic, hing, and roasted spices.',
    xPercent: 75,
    yPercent: 53,
  },
  {
    id: 6,
    name: 'Kesar Shrikhand',
    marathi: 'केशर श्रीखंड',
    role: 'Festive Sweet',
    description: '24-hour hung curd whipped with Kashmir saffron strands, nutmeg, and toasted pistachios.',
    xPercent: 27,
    yPercent: 49,
  },
  {
    id: 7,
    name: 'Chilled Kokum Solkadhi',
    marathi: 'सोलकढी',
    role: 'Coastal Digestive',
    description: 'Rose-pink coconut milk and tangy Konkan kokum infused with fresh coriander and cumin.',
    xPercent: 41,
    yPercent: 55,
  },
  {
    id: 8,
    name: 'Kothimbir Vadi & Thecha',
    marathi: 'कोथिंबीर वडी',
    role: 'Farsan Crunch',
    description: 'Sesame-crusted coriander cakes paired with mortar-pounded green chili peanut thecha.',
    xPercent: 69,
    yPercent: 73,
  },
  {
    id: 9,
    name: 'Khamang Koshimbir',
    marathi: 'खमंग कोशिंबीर',
    role: 'Fresh Relish',
    description: 'Crisp cucumber, ruby pomegranate, and roasted peanut salad tempered with mustard seeds.',
    xPercent: 54,
    yPercent: 77,
  },
  {
    id: 10,
    name: 'Crispy Sun-Dried Kurdai',
    marathi: 'कुरडई व पापड',
    role: 'Heirloom Crisp',
    description: 'Delicate hand-extruded wheat kurdai crisps fried light to balance rich curries.',
    xPercent: 41,
    yPercent: 77,
  },
  {
    id: 11,
    name: 'Kairi Lonche Pickle',
    marathi: 'कैरीचं लोणचं',
    role: 'House Preserve',
    description: 'Sun-cured raw mango pickle spiced with fenugreek, asafoetida, and Bedgi chili.',
    xPercent: 30,
    yPercent: 68,
  },
  {
    id: 12,
    name: 'Aamras / Seasonal Pour',
    marathi: 'हापूस आमरस',
    role: 'Chef’s Finish',
    description: 'Velvety Ratnagiri Alphonso mango nectar with cardamom served at table finale.',
    xPercent: 51,
    yPercent: 34,
  },
];

export const LOCATIONS: LocationInfo[] = [
  {
    id: 'mumbai',
    city: 'Mumbai',
    neighborhood: 'Bandra West',
    address: '14 Pali Mala Road, Off Carter Road, Bandra West, Mumbai 400050',
    hours: 'Daily 11:30 AM – 11:30 PM',
    phone: '+91 22 4890 3412',
    seatingNote: '48-cover courtyard & live Vada Pav counter',
    mapX: 28,
    mapY: 56,
    landmark: '2 mins from Pali Hill Promenade',
  },
  {
    id: 'pune',
    city: 'Pune',
    neighborhood: 'Koregaon Park',
    address: 'Lane 6, Meera Nagar, Koregaon Park, Pune 411001',
    hours: 'Tue–Sun 8:30 AM (Misal Breakfast) – 11:00 PM',
    phone: '+91 20 6721 8940',
    seatingNote: 'Heritage bungalow verandah & Thali dining room',
    mapX: 46,
    mapY: 66,
    landmark: 'Opposite Osho Teerth Botanical Walk',
  },
  {
    id: 'nagpur',
    city: 'Nagpur',
    neighborhood: 'Civil Lines',
    address: '22 Residency Road, Sadar-Civil Lines, Nagpur 440001',
    hours: 'Daily 12:00 PM – 11:00 PM',
    phone: '+91 712 254 7810',
    seatingNote: 'Saoji spice bar & private family dining room',
    mapX: 74,
    mapY: 36,
    landmark: 'Adjacent to Seminary Hills',
  },
];

export const REVIEWS = [
  {
    id: 'rev-1',
    name: 'Arundhati Kulkarni',
    role: 'Culinary Columnist, Mid-Day Mumbai',
    dishOrdered: 'Peri-Peri Misal Fondue & Puran Poli',
    quote:
      'Finally a kitchen that respects the soul of Sadashiv Peth while having genuine fun with Mumbai street craft. The Kolhapuri kat in the fondue still carries real stone-ground heat.',
    rating: '4.9 / 5',
  },
  {
    id: 'rev-2',
    name: 'Rohan Deshmukh',
    role: 'Architect & Bandra Regular',
    dishOrdered: 'Tandoori Cheese Burst Vada Pav',
    quote:
      'Brioche pav with molten cheddar shouldn’t work as well as it does with dry garlic chutney, yet it tastes unmistakably Maharashtrian. My Saturday evening ritual.',
    rating: '5.0 / 5',
  },
  {
    id: 'rev-3',
    name: 'Meera Patwardhan',
    role: 'Food Historian, Pune Heritage Walks',
    dishOrdered: 'Grand Maharashtrian Festive Thali',
    quote:
      'Their Thalipeeth loni and Indrayani varan bhaat remind me of my grandmother’s brass kitchen in Satara. Every katori arrives at the exact right temperature.',
    rating: '4.9 / 5',
  },
];
